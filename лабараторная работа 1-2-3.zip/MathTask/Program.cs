﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTask
{


    class Program
    {
        private readonly double p;

        #region Переменные круга         
        private double x1;
        private double y1;
        private double x2;
        private double y2;
        private double x3;
        private double y3;
        private double a;
        private double b;
        private double c;
        private double pr;
        private double S;
        #endregion

        #region Переменные задачи о ладье 

        private byte xx1;
        private byte yx1;
        private byte xx2;
        private byte yx2;
        #endregion

        #region Переменные задачи о числе 

        private string value;
        private byte aa;
        private byte ba;
        private byte ca;
        private int result;
        #endregion

        static void Main(string[] args)
        {
            Program ex = new Program();
            ex.FirstTask();
            ex.SecondTask();
            ex.ThirdTask();
            Console.ReadLine();
        }

        private void FirstTask()
        {


            this.x1 = 1;
            this.y1 = 2;
            this.x2 = 3;
            this.y2 = 4;
            this.x3 = 5;
            this.y3 = 6;

            a = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            b = Math.Sqrt(Math.Pow(x2 - x3, 2) + Math.Pow(y3 - y2, 2));
            c = Math.Sqrt(Math.Pow(x3 - x1, 2) + Math.Pow(x3 - y1, 2));
            

            if (a + b > c | a + c > b | b + c > a)
            {
                pr = (a + b + c) / 2;
                S = (pr *(pr-a)*(pr-b)*(pr-c))*0.5;



                
            }

            else
            {
                Console.Write("не правильно ведины кардинаты ведите снова");
            }

        


            
            Console.WriteLine("Площадь кольца между ними = {0}");
        }
        private void SecondTask()
        {
            //Проверить может ли попасть ладья за один ход из поля заданного 
            //координатами x1,y1 в поле заданное координатами x2,y2             
            Console.WriteLine("Введите вертикаль на которой находится ладья):");
            this.x1 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Введите горизонталь на которой находится ладья):");
            this.y1 = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Введите вертикаль поля на которое должна попасть ладья):");
            this.x2 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Введите горизонталь поля на которое должна попасть ладья):");
            this.y2 = Convert.ToByte(Console.ReadLine());

            if (x1 == x2 || y1 == y2)
            {
                Console.WriteLine("Данный ход ладьи возможен.");
            }
            else
            {
                Console.WriteLine("Данный ход ладьи невозможен!");
            }
        }
        private void ThirdTask()
        {
            //Дано трёхзначное число, найти сумму произведения его цифр             
            do
            {
                Console.WriteLine("Введите число:");
                this.value = Console.ReadLine();
            } while (value.Length != 3);

            this.a = byte.Parse(value[0].ToString());
            this.b = byte.Parse(value[1].ToString());
            this.c = byte.Parse(value[2].ToString());


            

            Console.WriteLine("Сумма произведения трёх цифр:{0}",
          this.result);

        }

    }
}