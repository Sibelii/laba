﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace лобараторная_работа__4_6
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y, z, max, min,F;
            x = 1;
            y = 2;
            z = 3;
            if(x>y+z)
            {
                min = y + z;
            }
            else
            {
                min = x;
            }
            if (x > y)
            {
                max = x*x;
            }
            else
            {
                max = y;
            }
            F = min / max + z * z * z;


            System.Console.WriteLine("F={0}", F);
            System.Console.ReadKey();
        }
    }
}
